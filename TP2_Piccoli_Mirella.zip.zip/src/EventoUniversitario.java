package modelo;
import exepciones.CupoExcedidoException;
import modelo.actividades.Actividad;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EventoUniversitario {
    private String nombre;
    private Sala sala;
    private List<Actividad> actividades;
    private List<Inscripcion> inscripciones;

    public EventoUniversitario(String nombre, Sala sala) {
        this.nombre = nombre;
        this.sala = sala;
        this.actividades = new ArrayList<>();
        this.inscripciones = new ArrayList<>();
    }

    public void agregarActividad(Actividad actividad) {
        this.actividades.add(actividad);
    }

    public void inscribirEstudiante(Estudiante estudiante, Date fecha) throws CupoExcedidoException {
        if (inscripciones.size() >= sala.getCapacidad()) {
            throw new CupoExcedidoException("No hay cupo disponible en la sala: " + sala.getNombre());
        }
        Inscripcion nuevaInscripcion = new Inscripcion(estudiante, fecha);
        inscripciones.add(nuevaInscripcion);
        System.out.println("Estudiante " + estudiante.getNombre() + " inscripto con éxito.");
    }

    public String getNombre() {
        return nombre;
    }

    public Sala getSala() {
        return sala;
    }

    public List<Actividad> getActividades() {
        return actividades;
    }

    public List<Inscripcion> getInscripciones() {
        return inscripciones;
    }
}