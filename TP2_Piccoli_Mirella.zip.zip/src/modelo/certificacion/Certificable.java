package modelo.certificacion;

public interface Certificable {
    boolean esCertificable();
    int obtenerHorasCertificables();
}