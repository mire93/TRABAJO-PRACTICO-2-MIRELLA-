package modelo.actividades;

public class Taller extends Actividad {
    private int cupoMaximo;

    public Taller(String nombre, int duracionHoras, int cupoMaximo) {
        super(nombre, duracionHoras);
        this.cupoMaximo = cupoMaximo;
    }

    public int getCupoMaximo() {
        return cupoMaximo;
    }

    @Override
    public boolean esCertificable() {
        return true;
    }

    @Override
    public int obtenerHorasCertificables() {
        return getDuracionHoras();
    }
}