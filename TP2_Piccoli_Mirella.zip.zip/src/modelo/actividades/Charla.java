package modelo.actividades;

public class Charla extends Actividad {
    private String Disertante;

    public Charla(String nombre, int duracionHoras, String Disertante) {
        super(nombre, duracionHoras);
        this.Disertante = Disertante;
    }

    public String getDisertante() {
        return Disertante;
    }

    @Override
    public boolean esCertificable() {
        return false;
    }

    @Override
    public int obtenerHorasCertificables() {
        return 0;
    }
}