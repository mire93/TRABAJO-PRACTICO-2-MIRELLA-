package modelo.actividades;

import modelo.certificacion.Certificable;

public abstract class Actividad implements Certificable {
    private String nombre;
    private int duracionHoras;

    public Actividad(String nombre, int duracionHoras) {
        this.nombre = nombre;
        this.duracionHoras = duracionHoras;
    }

    public String getNombre() {
        return nombre;
    }

    public int getDuracionHoras() {
        return duracionHoras;
    }
}