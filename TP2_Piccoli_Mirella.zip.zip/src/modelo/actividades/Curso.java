package modelo.actividades;

public class Curso extends Actividad {
    private double notaAprobacion;

    public Curso(String nombre, int duracionHoras, double notaAprobacion) {
        super(nombre, duracionHoras);
        this.notaAprobacion = notaAprobacion;
    }

    public double getNotaAprobacion() {
        return notaAprobacion;
    }

    @Override
    public boolean esCertificable() {
        return true;
    }

    @Override
    public int obtenerHorasCertificables() {
        return getDuracionHoras();
    }
}