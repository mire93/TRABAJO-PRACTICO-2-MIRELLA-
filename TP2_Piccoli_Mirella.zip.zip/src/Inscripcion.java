package modelo;

import java.util.Date;

public class Inscripcion {
    private Estudiante estudiante;
    private Date fecha;

    public Inscripcion(Estudiante estudiante, Date fecha) {
        this.estudiante = estudiante;
        this.fecha = fecha;
    }

    public Estudiante getEstudiante() {
        return estudiante;
    }

    public Date getFecha() {
        return fecha;
    }
}
