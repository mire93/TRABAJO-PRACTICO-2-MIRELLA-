import exepciones.CupoExcedidoException;
import modelo.Estudiante;
import modelo.EventoUniversitario;
import modelo.Sala;
import modelo.actividades.Charla;
import modelo.actividades.Curso;
import modelo.actividades.Taller;

import java.util.Date;

public class App {
    public static void main(String[] args) {
        System.out.println("=== INICIANDO PRUEBA DE EVENTO UNIVERSITARIO ===");

        // 1. Crear Sala y Evento
        Sala sala1 = new Sala("Aula Magna", 2); // Capacidad para 2 estudiantes
        EventoUniversitario evento = new EventoUniversitario("Jornadas de Tecnología", sala1);

        // 2. Crear Estudiantes
        Estudiante est1 = new Estudiante("12345", "Juan", "Pérez");
        Estudiante est2 = new Estudiante("67890", "María", "Gómez");
        Estudiante est3 = new Estudiante("11223", "Carlos", "López");

        // 3. Crear Actividades
        Charla charla = new Charla("Intro a Java", 2, "Dr. Rodríguez");
        Taller taller = new Taller("Taller Git", 3, 20);
        Curso curso = new Curso("Estructuras de Datos", 10, 85.0);

        evento.agregarActividad(charla);
        evento.agregarActividad(taller);
        evento.agregarActividad(curso);

        // 4. Probar Inscripciones y Excepción
        try {
            System.out.println("\nInscribiendo a " + est1.getNombre() + "...");
            evento.inscribirEstudiante(est1, new Date());

            System.out.println("Inscribiendo a " + est2.getNombre() + "...");
            evento.inscribirEstudiante(est2, new Date());

            // Esta tercera inscripción debe lanzar CupoExcedidoException.java
            System.out.println("Inscribiendo a " + est3.getNombre() + "...");
            evento.inscribirEstudiante(est3, new Date());

        } catch (CupoExcedidoException e) {
            System.err.println("\n[ERROR CAPTURADO] " + e.getMessage());
        }

        // 5. Mostrar Certificaciones
        System.out.println("\n=== CERTIFICACIONES ===");
        System.out.println("Charla certificable: " + charla.esCertificable() + " | Horas: " + charla.obtenerHorasCertificables());
        System.out.println("Taller certificable: " + taller.esCertificable() + " | Horas: " + taller.obtenerHorasCertificables());
        System.out.println("Curso certificable: " + curso.esCertificable() + " | Horas: " + curso.obtenerHorasCertificables());

        System.out.println("\n=== FIN DE LA EJECUCIÓN ===");
    }
}